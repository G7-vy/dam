
package com.example.stud118;
import androidx.appcompat.app.AppCompatActivity;
import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    DatabaseHelper db;

    EditText et_usn,et_name,et_sems;

    Button bt_save;
    Button bt_report;
    TextView tv_op;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        db = new DatabaseHelper(this);
        et_usn = (EditText)findViewById(R.id.et_usn);
        et_name = (EditText)findViewById(R.id.et_name);
        et_sems = (EditText)findViewById(R.id.et_sems);
        bt_save = (Button)findViewById(R.id.bt_save);
        bt_report = (Button)findViewById(R.id.bt_report);
        tv_op = (TextView)findViewById(R.id.tv_op);
    }
    public void inserti (View view) {
        boolean status = db.insert(
                Integer.parseInt(et_usn.getText().toString()),
                et_name.getText().toString(),
                Integer.parseInt(et_sems.getText().toString()));

        if(status){
            Toast.makeText(getApplicationContext(),"Record added",Toast.LENGTH_LONG).show();
            cleartext();
        }
        else{
            Toast.makeText(getApplicationContext(),"Record Not added",Toast.LENGTH_LONG).show();
        }
    }
    public void report(View view) {
        Cursor c = db.select();
        if (c.getCount() ==0)
            return;
        StringBuffer buf = new StringBuffer();
        while (c.moveToNext()) {
            buf.append ("USN: "+c.getString(0));
            buf.append("\n");
            buf.append ("Name: "+c.getString(1));
            buf.append("\n");
            buf.append ("Semester: "+c.getString(2));
            buf.append("\n");
            buf.append("\n");
        }
        tv_op.setText(buf);
    }
    public void cleartext () {
        et_name.setText("");
        et_usn.setText("");
        et_sems.setText("");

    }
}

