package com.example.expense118;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;

public class MainActivity extends AppCompatActivity {
String s1,s2;
EditText et1,et2;
TextView tv1;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et1=(EditText)findViewById(R.id.et1);
        et2=(EditText)findViewById(R.id.et2);
        tv1=(TextView)findViewById(R.id.tv1);
    }
    public void save(View view)
    {
        s1=et1.getText().toString();
        s2=s1+" "+et2.getText().toString()+"\n";
        try{
            FileOutputStream fos=openFileOutput("expense.txt",MODE_APPEND);
            fos.write(s2.getBytes());
            Toast.makeText(getApplicationContext(),"Added",Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(getApplicationContext(),"Error",Toast.LENGTH_LONG).show();
        }
        et1.setText("");
        et2.setText("");
    }
    public void load(View view)
    {
        s1=et1.getText().toString();
        s2=s1+" "+et1.getText().toString()+"\n";
        try{
            FileInputStream fis=openFileInput("expense.txt");
           InputStreamReader isr=new InputStreamReader(fis);
            BufferedReader br=new BufferedReader(isr);
            StringBuilder sb=new StringBuilder();
            String text;
            while((text=br.readLine())!=null){
                sb.append(text);
                sb.append("\n");
            }
            tv1.setText(sb.toString());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}