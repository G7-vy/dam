package com.example.sms218;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.*;
import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.app.Activity;


import android.telephony.SmsManager;

import android.util.Log;
import android.view.Menu;
import android.view.View;

import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
public class MainActivity extends AppCompatActivity {
    private EditText m1,m2;
    private Button mb;
    String phoneNo,message;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        m1=(EditText) findViewById(R.id.m1);
        m2=(EditText) findViewById(R.id.m2);
        mb=(Button) findViewById(R.id.mb);
        mb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(m1.getText().toString().equals("")||m2.getText().toString().equals("")){
                    Toast.makeText(getApplicationContext(), "Enter fields", Toast.LENGTH_SHORT).show();
                }
                else{
                    try{
                        SmsManager smgr=SmsManager.getDefault();
                        smgr.sendTextMessage(m1.getText().toString().trim(),null,m2.getText().toString().trim(),null,null);
                        Toast.makeText(getApplicationContext(), "SMS SENT", Toast.LENGTH_SHORT).show();
                    }
                    catch(Exception e){
                        Toast.makeText(getApplicationContext(), "SMS SENT", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }

}
