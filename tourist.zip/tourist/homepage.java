package com.example.tourist;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class homepage extends AppCompatActivity {

    ImageView img1,img2,img3;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_homepage);
        img1=(ImageView) findViewById(R.id.img_1);
        img2=(ImageView) findViewById(R.id.img_2);
        img3=(ImageView) findViewById(R.id.img_3);

        img1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(homepage.this,"Attukad Waterfalls", Toast.LENGTH_SHORT).show();
                String u1="https://www.thrillophilia.com/attractions/attukad-waterfalls";
                Intent i1=new Intent( Intent.ACTION_VIEW, Uri.parse(u1));
                startActivity(i1);
            }
        });

        img2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(homepage.this,"Lloyd Botanical Garden",Toast.LENGTH_SHORT).show();
                String u1="https://darjeeling.gov.in/tourist-place/lloyd-botanical-garden/";
                Intent i1=new Intent( Intent.ACTION_VIEW,Uri.parse(u1));
                startActivity(i1);
            }
        });

        img3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(homepage.this,"Nubra Valley ",Toast.LENGTH_SHORT).show();
                String u1="https://www.holidify.com/places/ladakh/nubra-valley-area.html";
                Intent i1=new Intent( Intent.ACTION_VIEW,Uri.parse(u1));
                startActivity(i1);
            }
        });
    }
}
